/* global React */
const { useState } = React;

function DocBand({ crumb, title, right }) {
  return (
    <header className="docband">
      <div>
        <div className="crumb">{crumb}</div>
        <h1><span className="pi">π</span>-chart <span style={{color:"var(--ink-3)"}}>/</span> {title}</h1>
      </div>
      <div className="docband-right">
        {right.rows.map((row, i) => (
          <div className="row" key={i}>
            {row.map((cell, j) => <span key={j} dangerouslySetInnerHTML={{__html: cell}} />)}
          </div>
        ))}
        {right.stamps?.map((s, i) => (
          <span key={i} className={"stamp " + (s.kind || "")}>{s.label}</span>
        ))}
      </div>
    </header>
  );
}

function PatientBar({ patient }) {
  return (
    <section className="patientbar">
      <div className="cell">
        <div className="k">patient</div>
        <div className="patient-name">{patient.name}</div>
        <div className="patient-meta">{patient.demo}</div>
      </div>
      <div className="cell">
        <div className="k">acuity</div>
        <span className="acuity"><span className="dot"></span>{patient.acuity}</span>
        <div className="micro">{patient.acuityMeta}</div>
      </div>
      <div className="cell">
        <div className="k">constraints</div>
        <div className="patient-meta">{patient.constraints}</div>
        <div className="micro">{patient.code}</div>
      </div>
      <div className="cell">
        <div className="k">cycle</div>
        <div className="patient-meta">{patient.cycle}</div>
        <div className="micro">{patient.cycleMeta}</div>
      </div>
    </section>
  );
}

window.DocBand = DocBand;
window.PatientBar = PatientBar;
