# π-chart UI Kit

High-fidelity recreation of the **π-chart cockpit + agent canvas** — the read-only review surface and agent draft scratchpad.

## Source of truth

- `pi-chart/docs/prototypes/pi-chart-cockpit.html` (review cockpit)
- `pi-chart/docs/prototypes/pi-chart-scratchpad.html` (agent canvas)
- `pi-chart/scripts/agent-canvas.ts` (v0.4 generator)

## What's in here

| File | Component | What it is |
|---|---|---|
| `index.html` | — | Interactive recreation. Tab between Cockpit and Agent Canvas. Open artifacts, stage/commit. |
| `DocBand.jsx` | `<DocBand>` | Top header band — brand line + crumb left, mono status right |
| `PatientBar.jsx` | `<PatientBar>` | Edge-to-edge patient strip — name, acuity, code, status |
| `VitalsRow.jsx` | `<VitalsRow>` `<VitalTile>` | Streaming vitals with sparklines, signal mode |
| `Nav.jsx` | `<Nav>` | Grouped left rail nav |
| `EventStream.jsx` | `<EventStream>` `<EventRow>` | Clinical timeline events |
| `Trend.jsx` | `<Trend>` | Sparkline trend panel (single + paired) |
| `DraftBand.jsx` | `<DraftBand>` | Agent draft overlay band |
| `ArtifactCard.jsx` | `<ArtifactCard>` | Agent-generated draft with stage / commit |
| `AgentChat.jsx` | `<AgentChat>` | Bottom co-pilot chat surface |
| `CommitBar.jsx` | `<CommitBar>` | Sticky commit-cycle footer |
| `MemoryProof.jsx` | `<MemoryProof>` | Composed assessment narrative panel |

## Run

Open `index.html` in a browser. No build step.
