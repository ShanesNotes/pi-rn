/* global React */
const { useState: useStateAC } = React;

function AgentChat({ messages, onSend }) {
  const [val, setVal] = useStateAC("");
  return (
    <section className="chat">
      <div className="chat-head">
        <span>pi-agent · co-pilot</span>
        <span>Chat is process. Chartable output lands in the scratchpad — never in chat.</span>
      </div>
      <div className="chat-body">
        {messages.map((m, i) => (
          <div className="msg" key={i}>
            <div className={"who " + (m.who === "pi-agent" ? "agent" : "")}>{m.who}<br/>{m.time}</div>
            <div className="txt">{m.text}</div>
            <div className="scope">{m.scope || ""}</div>
          </div>
        ))}
      </div>
      <div className="composer">
        <textarea
          placeholder="Ask pi-agent to draft, refine, or attach. Output appears in the scratchpad — not in chat."
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              if (val.trim()) {
                onSend && onSend(val.trim());
                setVal("");
              }
            }
          }}
        />
        <button
          className="btn dark"
          onClick={() => {
            if (val.trim()) {
              onSend && onSend(val.trim());
              setVal("");
            }
          }}
        >send ↵</button>
      </div>
    </section>
  );
}

function CommitBar({ summary, onCommit, onDiscard }) {
  return (
    <div className="commitbar">
      <span dangerouslySetInnerHTML={{__html: summary}} />
      <span className="actions">
        <span onClick={onDiscard}>discard</span>
        <span className="primary" onClick={onCommit}>commit cycle</span>
      </span>
    </div>
  );
}

window.AgentChat = AgentChat;
window.CommitBar = CommitBar;
