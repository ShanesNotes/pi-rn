/* global React */
function MemoryProof({ paragraphs, chips }) {
  return (
    <section className="note">
      <div className="ph">
        <h3>Assessment memory proof</h3>
        <span className="ct">memoryProof().why_it_mattered</span>
      </div>
      <div className="body-wrap">
        {paragraphs.map((p, i) => <p key={i}>{p}</p>)}
        {chips && (
          <div className="chips">
            {chips.map((c, i) => <span key={i} className="chip">{c}</span>)}
          </div>
        )}
      </div>
    </section>
  );
}

function OpenLoops({ items }) {
  return (
    <section className="panel">
      <div className="ph"><h3>Open loops</h3><span className="ct">openLoops()</span></div>
      <div className="body-wrap">
        {items.map((it, i) => (
          <div className="item" key={i}>
            <div className="marker fill"></div>
            <div>
              <div className="ttl">{it.title}</div>
              <div className="sub">{it.sub}</div>
            </div>
            <div className="meta">{it.status}<br/>{it.due}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

window.MemoryProof = MemoryProof;
window.OpenLoops = OpenLoops;
