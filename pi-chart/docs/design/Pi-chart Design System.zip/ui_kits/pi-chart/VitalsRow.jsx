/* global React */
function VitalTile({ label, value, unit, delta, signal, points }) {
  return (
    <div className={"vital" + (signal ? " signal" : "")}>
      <div className="k">{label}</div>
      <div className="n">{value}<small>{unit}</small></div>
      <div className="d">{delta}</div>
      {points && (
        <svg className="spark" viewBox="0 0 120 24" aria-hidden="true">
          <polyline points={points} />
        </svg>
      )}
    </div>
  );
}

function VitalsRow({ vitals }) {
  return (
    <section className="vitals">
      {vitals.map((v, i) => <VitalTile key={i} {...v} />)}
    </section>
  );
}

window.VitalTile = VitalTile;
window.VitalsRow = VitalsRow;
