/* global React */
function Trend({ title, now, points, label }) {
  return (
    <section className="trend">
      <div className="head">
        <div className="title">{title}</div>
        <div className="now">{now}</div>
      </div>
      <svg viewBox="0 0 360 92" aria-hidden="true">
        <polyline points={points} />
      </svg>
      <div className="meta">{label}</div>
    </section>
  );
}

function MultiTrend({ title, lines, label }) {
  return (
    <section className="trend">
      <div className="head">
        <div className="title">{title}</div>
        <div className="now">paired <small>trend()</small></div>
      </div>
      <div className="multi-trend">
        {lines.map((l, i) => (
          <div className="mini-line" key={i}>
            <div className="mini-label">{l.label}</div>
            <svg viewBox="0 0 220 32" aria-hidden="true"><polyline points={l.points} /></svg>
            <div className="mini-now">{l.now}</div>
          </div>
        ))}
      </div>
      <div className="meta">{label}</div>
    </section>
  );
}

window.Trend = Trend;
window.MultiTrend = MultiTrend;
