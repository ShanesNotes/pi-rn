/* global React */
function EventRow({ time, type, summary, source, signal }) {
  return (
    <div className={"event-row" + (signal ? " signal" : "")}>
      <div className="event-time">{time}</div>
      <div className="event-type">{type}</div>
      <div className="event-summary" title={summary}>{summary}</div>
      <div className="event-source">{source}</div>
    </div>
  );
}

function EventStream({ events, title, count, tabs }) {
  return (
    <section className="panel">
      <div className="ph">
        <h2>{title || "Clinical event stream"}</h2>
        {tabs && (
          <div className="tabs">
            {tabs.map((t,i) => <span key={i} className={t.on ? "on" : ""}>{t.label}</span>)}
          </div>
        )}
        <span className="ct">{count}</span>
      </div>
      <div className="event-stream">
        {events.map((e, i) => <EventRow key={i} {...e} />)}
      </div>
    </section>
  );
}

window.EventRow = EventRow;
window.EventStream = EventStream;
