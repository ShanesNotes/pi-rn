/* global React */
function Nav({ groups, activeId, onSelect }) {
  return (
    <aside className="nav">
      {groups.map((g, i) => (
        <React.Fragment key={i}>
          <div className="group">{g.label}</div>
          {g.items.map((it) => (
            <a
              key={it.id}
              className={
                (it.id === activeId ? "active " : "") +
                (it.alert ? "alert" : "")
              }
              onClick={() => onSelect && onSelect(it.id)}
            >
              <span>{it.label}</span>
              <span className="ct">{it.ct}</span>
            </a>
          ))}
        </React.Fragment>
      ))}
      <div className="nav-foot">Agent Canvas is a workspace. The chart remains canonical.</div>
    </aside>
  );
}

window.Nav = Nav;
