/* global React */
function DraftBand({ drafts }) {
  return (
    <section className="draft-band">
      <div className="label">Pi-agent draft overlay · not committed</div>
      <div className="draft-grid">
        {drafts.map((d, i) => (
          <div className="draft-card" key={i}>
            <div className="type">{d.type}</div>
            <div className="title">{d.title}</div>
            <div className="sub">{d.sub}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ArtifactCard({ artifact, onAct }) {
  const a = artifact;
  return (
    <button className={"artifact " + (a.active ? "active" : "")} onClick={() => onAct && onAct("open", a.id)}>
      <div className="top">
        <div>
          <div className="tag">{a.kind}</div>
          <h3>{a.title}</h3>
        </div>
        <span className={"status " + a.status}>□ {a.status}</span>
      </div>
      <p>{a.summary}</p>
      <div className="confidence">
        <span>supports {a.supports} · {a.run}</span>
        <span>conf <span className="bar"></span> {a.confidence}%</span>
      </div>
    </button>
  );
}

window.DraftBand = DraftBand;
window.ArtifactCard = ArtifactCard;
